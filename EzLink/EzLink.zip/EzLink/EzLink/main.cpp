#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "ezlink-host.h"
#include "serial.h"


#define RETURN_ON_ERROR(Status)             \
{                                      \
int _UNIQUE_VAR = (Status);        \
if (_UNIQUE_VAR < 0)        \
{                                  \
return _UNIQUE_VAR;            \
}                                  \
}

/* This is just a dummy command to illustrate the transition from command mode to EzLink mode */
char *DiagsCmds[] = {
    "ver\n",
    "sn\n",
    "consolerouter --add --src Tallaght --dest ramlog\n",
    "tristar --prov_status\n"
    //    "tristar --provision\r\n"
};

#define DIAGS_CMD_TIMEOUT_MS 400

int main(int Argc, char *Argv[]) {
    EzLinkTransport_t Methods;
    SerialContext_t SerialContext;
    EzLink_t EzLinkInfo;
    ErrorInfo_t *ErrorInfo;
    int Status;
    //    char Buf[20];
    int i;
    uint8_t *RxBuf;
    uint32_t RxBufSize;
    uint8_t TmpBuf[2709];
    char ReadBuf[2050];
    
    Methods.TxData = Serial_WriteBytes;
    Methods.RxData = Serial_ReadBytes;
    
    //    if (Argv[1]==NULL)
    //	{
    //		printf("Please input a argument!\n");
    //		return -1;
    //	}
    //    Status = Serial_Open(Argv[1], &SerialContext.Fd, 115200);
    Status = Serial_Open("/dev/cu.usbserial-AM01WBKM", &SerialContext.Fd, 115200);
    
    if (Status < 0) {
        printf("Error opening serial port!\n");
        return -1;
    }
    
    
    for (i = 0; i < (sizeof(DiagsCmds) / sizeof(DiagsCmds[0])); i++) {
        memset(ReadBuf,0x00,2050);
        write(SerialContext.Fd, DiagsCmds[i], strlen(DiagsCmds[i]) + 1);
        usleep(500);
        read(SerialContext.Fd,ReadBuf,2050);
        printf(ReadBuf);
        usleep(500);
    }
    
    char * cmd = "tristar --provision\r\n";
    write(SerialContext.Fd,cmd,strlen(cmd)+1);
    read(SerialContext.Fd,ReadBuf,200);
    printf(ReadBuf);
    
    /* Give diags enough time to get prepped and ready */
    usleep(100 * 1000);
    
    /* 1. Setup the Ezlink with diags */
    Status = EzLink_Setup(&EzLinkInfo, &Methods, &SerialContext);
    if (Status < 0)
    {
        printf("Error setup the EzLink with diags!\n");
        return Status;
    }
    //    RETURN_ON_ERROR(Status);
    
    /* Phase 1 - Receive the provisioning request from diags */
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf, &RxBufSize, DIAGS_CMD_TIMEOUT_MS, &ErrorInfo);
    if (Status < 0)
    {
        printf("Error receiver the provisioning request from diags!\n");
        return Status;
    }
    //    RETURN_ON_ERROR(Status);
    
    printf("Received %u bytes\n", RxBufSize);
    
    // send the JMET errors
    if(strcmp(ErrorInfo->ErrorString, "") < 0)
    {
        //        EzLink_SendError(&EzLinkInfo, ErrorInfo->ErrorCode, ErrorInfo->ErrorString);
        printf("Error JMET parse the data has some errors: %s\n",ErrorInfo->ErrorString);
        return -1;
    }
    else
    {
        /* Phase 2 - Send the provisioning info from JMET to diags */
        Status = EzLink_SendData(&EzLinkInfo, TmpBuf, sizeof(TmpBuf), DIAGS_CMD_TIMEOUT_MS, &ErrorInfo);
        //        RETURN_ON_ERROR(Status);
        if(Status != 0) // we should chck the status_code be 0  ???
        {
            printf("Error send the provisioning info from JMET to diaga!\n");
            return Status;
        }
    }
    
    /* Phase 3 - Get the provioning response back from diags */
    Status = EzLink_RecvData(&EzLinkInfo, (void **)&RxBuf, &RxBufSize, DIAGS_CMD_TIMEOUT_MS, &ErrorInfo);
    if (Status < 0)
    {
        printf("Error get the provioning response back from diag!\n");
        return Status;
    }
    //    RETURN_ON_ERROR(Status);
    
    printf("Received %u bytes\n", RxBufSize);
    return 0;
}
